import {React} from 'react'

const SignUp=()=>{
 return(
   <p>Sign Up</p>
 )
}

export  default  SignUp